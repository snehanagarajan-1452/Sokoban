# Revision 2 experiments: learned dead-end pruning (RB-THC-L) and A*

Adds two solvers to the original notebook, run on the same 300 Boxoban test levels, 5 seeds, 3,000-expansion budget.
`rbthc_core.py` is the original notebook code (cells 2-6 and 17), unchanged; it reproduces `main_runs.csv` exactly.

Steps (Linux, Python 3, scikit-learn >= 1.3); clone https://github.com/google-deepmind/boxoban-levels first:
1. `python gen.py` - labelled states from 450 TRAINING levels (unfiltered/train/000, medium/train/000, hard/001; no overlap with test files) -> train.pkl
2. `python train2.py` - 5-fold level-grouped CV (AUC 0.948, precision 0.996 / recall 0.69 at tau = 0.9), then fits the classifier -> clf_gbt.pkl
3. `OMP_NUM_THREADS=1 python run_new.py RB-THC-D,A* 100 full_new.csv` - RB-THC-L (named RB-THC-D in code) and A* on all test levels
4. `python stats.py` - solve rates, bootstrap CIs, McNemar / Wilcoxon tests (needs main_runs.csv and gbfs_capped_runs.csv)

Set OMP_NUM_THREADS=1 when running in parallel, otherwise classifier threads oversubscribe the CPU.
