from learned import *
import learned as L, dataclasses, multiprocessing as mp, pickle
from concurrent.futures import ProcessPoolExecutor
UNSOLVED = 60.0
SRC = [('boxoban-levels/unfiltered/train/000.txt', 'utrain'),
       ('boxoban-levels/medium/train/000.txt', 'mtrain'),
       ('boxoban-levels/hard/001.txt', 'htrain')]
TRAIN = []
for path, pre in SRC:
    allv = load_file(path, pre); rng = random.Random(1)
    TRAIN += [lv for lv in rng.sample(allv, 150) if not validate(lv)]
P = dict(CFG)

def from_state(lv, s):
    return dataclasses.replace(lv, boxes0=s[1], player0=s[0])

def one(i):
    lv = TRAIN[i]; rng = random.Random(i); X, y, g = [], [], []
    r = gbfs(lv, random.Random(0), dict(P, max_expansions=3000))
    # recover path by re-running with node access
    ctr = Counter(10**9, 1e9)
    if r['solved']:
        # rerun GBFS keeping the node to read the path
        s0 = canon(lv, lv.player0, lv.boxes0)
        openl = [(heuristic(lv, s0[1], 'matching'), random.Random(0).random(), (s0, None))]; closed = {s0}; rr = random.Random(0); rr.random()
        node = None
        while openl:
            h, _, nd = heapq.heappop(openl)
            if is_goal(lv, nd[0]): node = nd; break
            for s in successors(lv, nd[0], ctr):
                if s not in closed:
                    closed.add(s); heapq.heappush(openl, (heuristic(lv, s[1], 'matching'), rr.random(), (s, nd)))
            if ctr.exp > 6000: break
        if node:
            states = path_states(node); n = len(states) - 1
            for j, s in enumerate(states): X.append(feats(lv, s)); y.append(float(n - j)); g.append(i)
    # off-path states from random push walks; label with a fresh GBFS solve
    s0 = canon(lv, lv.player0, lv.boxes0)
    for _ in range(10):
        node = C._random_walk(lv, s0, rng, rng.randint(2, 15), Counter(10**9, 1e9))
        s = node[0]
        if is_goal(lv, s): continue
        sub = gbfs(from_state(lv, s), random.Random(0), dict(P, max_expansions=1500))
        X.append(feats(lv, s)); y.append(float(sub['pushes']) if sub['solved'] else UNSOLVED); g.append(i)
    return X, y, g

if __name__ == '__main__':
    t0 = time.time(); Xs, ys, gs = [], [], []
    with ProcessPoolExecutor(2, mp_context=mp.get_context('fork')) as ex:
        for X, y, g in ex.map(one, range(len(TRAIN)), chunksize=4):
            Xs += X; ys += y; gs += g
    pickle.dump((np.array(Xs), np.array(ys), np.array(gs)), open('train.pkl', 'wb'))
    y = np.array(ys); print(len(TRAIN), 'levels', len(y), 'samples', (y == UNSOLVED).mean().round(3), 'unsolved frac', f'{time.time()-t0:.0f}s')
