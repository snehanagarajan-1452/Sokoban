import os
# CELL 2: imports + global config
import collections, heapq, json, math, platform, random, time
from dataclasses import dataclass, field, asdict
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from scipy.stats import wilcoxon, binomtest

CFG = dict(
    tiers={                       # tier -> (file, n levels sampled)
        'unfiltered': ('boxoban-levels/unfiltered/test/000.txt', 100),
        'medium':     ('boxoban-levels/medium/valid/000.txt', 100),
        'hard':       ('boxoban-levels/hard/000.txt', 100),
    },
    level_sample_seed=0,
    seeds=[0, 1, 2, 3, 4],        # per stochastic solver; every solver runs all seeds
    max_expansions=3000,          # node budget per run (identical for all solvers)
    time_limit=10.0,              # seconds per run (safety cap)
    heuristic='matching',         # 'matching' (Hungarian on push distance) or 'nearest' (paper Eq. 2 style)
    beam_width=4,
    tabu_size=500,
    patience=50,                  # RB-THC: restart after this many iters without best-h improvement
    walk_len=3,                   # random pushes from start state on restart
    n_workers=os.cpu_count(),
)

# CELL 3: level loading + static analysis (dead squares, push distances)
@dataclass
class Level:
    name: str
    W: int
    H: int
    walls: frozenset
    floor: frozenset       # cells reachable by player ignoring boxes
    goals: tuple
    boxes0: tuple
    player0: int
    dirs: tuple = ()
    dead: frozenset = frozenset()
    gdist: np.ndarray = None   # (n_goals, W*H) push distance box->goal, ignoring other boxes

def parse_xsb(lines, name):
    rows = [l.rstrip('\n') for l in lines if l.strip()]
    H = len(rows); W = max(len(r) for r in rows)
    rows = [r.ljust(W) for r in rows]
    walls, goals, boxes = set(), set(), set(); player = None
    for r, row in enumerate(rows):
        for c, ch in enumerate(row):
            i = r * W + c
            if ch == '#': walls.add(i)
            if ch in '.*+': goals.add(i)
            if ch in '$*': boxes.add(i)
            if ch in '@+': player = i
    return build_level(name, W, H, walls, goals, boxes, player)

def build_level(name, W, H, walls, goals, boxes, player):
    dirs = (-W, W, -1, 1)
    # floor = player-reachable ignoring boxes (outside-of-level spaces excluded)
    floor = {player}; q = collections.deque([player])
    while q:
        p = q.popleft()
        for d in dirs:
            n = p + d
            if 0 <= n < W * H and n not in walls and n not in floor and abs((n % W) - (p % W)) <= 1:
                floor.add(n); q.append(n)
    goals_t = tuple(sorted(goals))
    # reverse "pull" BFS from each goal -> push distance; cells with inf to every goal are dead
    gdist = np.full((len(goals_t), W * H), np.inf)
    for gi, g in enumerate(goals_t):
        gdist[gi, g] = 0; q = collections.deque([g])
        while q:
            b = q.popleft()
            for d in dirs:
                prev = b - d; ply = prev - d        # box was at prev, player at prev-d, pushed by +d
                if prev in floor and ply in floor and gdist[gi, prev] == np.inf:
                    gdist[gi, prev] = gdist[gi, b] + 1; q.append(prev)
    dead = frozenset(c for c in floor if np.all(np.isinf(gdist[:, c])))
    return Level(name, W, H, frozenset(walls), frozenset(floor), goals_t, tuple(sorted(boxes)),
                 player, dirs, dead, gdist)

def validate(lv):
    if len(lv.boxes0) != len(lv.goals): return 'box/goal count mismatch'
    if any(b in lv.dead and b not in lv.goals for b in lv.boxes0): return 'box starts on dead square'
    if any(b not in lv.floor for b in lv.boxes0): return 'box outside floor'
    return None

def load_file(path, prefix):
    levels, buf, name = [], [], None
    for line in open(path):
        if line.startswith(';'):
            if buf: levels.append(parse_xsb(buf, name))
            name = f"{prefix}:{line[1:].strip()}"; buf = []
        elif line.strip(): buf.append(line)
    if buf: levels.append(parse_xsb(buf, name))
    return levels

LEVELS = {}
for tier, (path, n) in CFG['tiers'].items():
    allv = load_file(path, tier)
    rng = random.Random(CFG['level_sample_seed'])
    chosen = rng.sample(allv, min(n, len(allv)))
    bad = [(lv.name, validate(lv)) for lv in chosen if validate(lv)]
    if bad: print('INVALID levels dropped:', bad)
    LEVELS[tier] = [lv for lv in chosen if not validate(lv)]
    print(f"{tier:10s} {len(LEVELS[tier])} levels from {path}")
# To add Microban (or any XSB/.sok file): LEVELS['microban'] = load_file('Microban.txt', 'microban')
# CELL 4: state space, heuristic, successor generation
# A state is (canonical_player, boxes) where canonical_player = min player-reachable cell,
# so states differing only in player position within the same region are identical (tabu/dedupe).

def reach(lv, player, boxes_set):
    seen = {player}; q = collections.deque([player])
    while q:
        p = q.popleft()
        for d in lv.dirs:
            n = p + d
            if n in lv.floor and n not in boxes_set and n not in seen:
                seen.add(n); q.append(n)
    return seen

def canon(lv, player, boxes):
    return (min(reach(lv, player, set(boxes))), boxes)

def is_goal(lv, state):
    return state[1] == lv.goals

def heuristic(lv, boxes, kind):
    if kind == 'matching':      # min-cost box->goal assignment on true push distances (admissible)
        cost = lv.gdist[:, list(boxes)].T
        cost = np.where(np.isinf(cost), 1e6, cost)
        r, c = linear_sum_assignment(cost)
        return float(cost[r, c].sum())
    # 'nearest': paper Eq. 2 — sum of nearest-goal Manhattan distances
    W = lv.W
    return float(sum(min(abs(b // W - g // W) + abs(b % W - g % W) for g in lv.goals) for b in boxes))

class Counter:
    def __init__(self, budget, tlimit):
        self.exp = 0; self.gen = 0; self.mem = 1; self.budget = budget; self.t0 = time.perf_counter(); self.tl = tlimit
    def out(self):
        return self.exp >= self.budget or time.perf_counter() - self.t0 > self.tl

def successors(lv, state, ctr):
    """All legal pushes; pushes onto dead squares are pruned (same for every solver)."""
    ctr.exp += 1
    player, boxes = state; bset = set(boxes)
    r = reach(lv, player, bset); out = []
    for b in boxes:
        for d in lv.dirs:
            dest = b + d
            if (b - d) in r and dest in lv.floor and dest not in bset and dest not in lv.dead:
                nb = tuple(sorted((bset - {b}) | {dest}))
                out.append(canon(lv, b, nb)); ctr.gen += 1
    return out

def path_len(node):
    n = 0
    while node[1] is not None: node = node[1]; n += 1
    return n

def path_states(node):
    s = []
    while node is not None: s.append(node[0]); node = node[1]
    return s[::-1]

def verify(lv, states):
    """Independent check: consecutive states differ by one legal push and last is solved."""
    dummy = Counter(10**12, 1e9)
    for a, b in zip(states, states[1:]):
        if b not in successors(lv, a, dummy): return False
    return is_goal(lv, states[-1])
# CELL 5: solvers. Every solver returns a dict; nodes are (state, parent_node) linked lists.

def _result(lv, solved, best_node, best_h, ctr, reason, trace):
    states = path_states(best_node) if best_node else []
    ok = verify(lv, states) if solved else False
    return dict(solved=bool(solved and ok), verified=ok if solved else None,
                pushes=path_len(best_node) if solved else np.nan,
                expansions=ctr.exp, generated=ctr.gen, peak_stored_states=ctr.mem,
                time=time.perf_counter() - ctr.t0, best_h=best_h,
                reason=reason, trace=trace + ([(ctr.exp, 0.0)] if solved else []))

def _rank(cands, rng):
    # sort by h, random tie-break (seeded) -> repeated runs genuinely differ
    return sorted(cands, key=lambda x: (x[0], rng.random()))

def _random_walk(lv, start, rng, n, ctr):
    node = (start, None)
    for _ in range(n):
        s = successors(lv, node[0], ctr)
        if not s: break
        node = (rng.choice(s), node)
    return node

def hill_climb(lv, rng, P, restarts=False):
    """Steepest-descent HC; stops at local optimum (plain) or restarts via random walk (HC-RR)."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    s0 = canon(lv, lv.player0, lv.boxes0)
    node = (s0, None); h = heuristic(lv, s0[1], hk)
    best_node, best_h, trace = node, h, []
    while not ctr.out():
        if is_goal(lv, node[0]): return _result(lv, True, node, 0.0, ctr, 'solved', trace)
        cands = _rank([(heuristic(lv, s[1], hk), s) for s in successors(lv, node[0], ctr)], rng)
        trace.append((ctr.exp, best_h))
        if cands and cands[0][0] < h:
            h, node = cands[0][0], (cands[0][1], node)
            if h < best_h: best_h, best_node = h, node
        elif restarts:
            node = _random_walk(lv, s0, rng, P['walk_len'], ctr); h = heuristic(lv, node[0][1], hk)
        else:
            return _result(lv, False, best_node, best_h, ctr, 'local_optimum', trace)
    return _result(lv, False, best_node, best_h, ctr, 'budget', trace)

def rb_thc(lv, rng, P, k, tabu_size, restarts):
    """Unified beam/tabu local search.
       k=1, tabu>0      -> plain Tabu search
       k>1, tabu=0      -> plain Beam search (no memory)
       k>1, tabu>0      -> RB-THC ; restarts=True adds stagnation-triggered random restarts."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    s0 = canon(lv, lv.player0, lv.boxes0)
    start = (s0, None)
    best_node, best_h, trace = start, heuristic(lv, s0[1], hk), []
    while True:
        beam = [(heuristic(lv, start[0][1], hk), start)]
        tabu = collections.deque(); tabu_set = set(); stall = 0
        while not ctr.out():
            for h, nd in beam:
                if is_goal(lv, nd[0]): return _result(lv, True, nd, 0.0, ctr, 'solved', trace)
            cands, seen = [], set()
            for h, nd in beam:
                if ctr.out(): break
                for s in successors(lv, nd[0], ctr):
                    if s in tabu_set or s in seen: continue
                    seen.add(s); cands.append((heuristic(lv, s[1], hk), (s, nd)))
            # tabu: add current beam states (FIFO, fixed tenure)
            if tabu_size:
                for h, nd in beam:
                    if nd[0] not in tabu_set:
                        tabu.append(nd[0]); tabu_set.add(nd[0])
                        if len(tabu) > tabu_size: tabu_set.discard(tabu.popleft())
            if not cands: break
            beam = _rank(cands, rng)[:k]
            ctr.mem = max(ctr.mem, len(tabu_set) + len(beam))
            if beam[0][0] < best_h: best_h, best_node, stall = beam[0][0], beam[0][1], 0
            else: stall += 1
            trace.append((ctr.exp, best_h))
            if restarts and stall >= P['patience']: break
        if ctr.out():
            return _result(lv, False, best_node, best_h, ctr, 'budget', trace)
        if not restarts:
            return _result(lv, False, best_node, best_h, ctr, 'no_candidates', trace)
        start = _random_walk(lv, s0, rng, P['walk_len'], ctr)

def gbfs(lv, rng, P):
    """Greedy best-first search with closed list: complete within budget (global-search reference)."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    s0 = canon(lv, lv.player0, lv.boxes0); h0 = heuristic(lv, s0[1], hk)
    openl = [(h0, rng.random(), (s0, None))]; closed = {s0}
    best_node, best_h, trace = (s0, None), h0, []
    while openl and not ctr.out():
        h, _, nd = heapq.heappop(openl)
        if is_goal(lv, nd[0]): return _result(lv, True, nd, 0.0, ctr, 'solved', trace)
        if h < best_h: best_h, best_node = h, nd
        for s in successors(lv, nd[0], ctr):
            if s not in closed:
                closed.add(s); heapq.heappush(openl, (heuristic(lv, s[1], hk), rng.random(), (s, nd)))
        ctr.mem = len(closed)
        trace.append((ctr.exp, best_h))
    return _result(lv, False, best_node, best_h, ctr, 'budget' if openl else 'exhausted', trace)

def make_solvers(P, k=None, tabu=None):
    k = k or P['beam_width']; tabu = P['tabu_size'] if tabu is None else tabu
    return {  # name -> (fn, stochastic?)
        'HC':          (lambda lv, rng: hill_climb(lv, rng, P, False), True),
        'HC-RR':       (lambda lv, rng: hill_climb(lv, rng, P, True), True),
        'Beam':        (lambda lv, rng: rb_thc(lv, rng, P, k, 0, False), True),
        'Tabu':        (lambda lv, rng: rb_thc(lv, rng, P, 1, tabu, False), True),
        'RB-THC-noRR': (lambda lv, rng: rb_thc(lv, rng, P, k, tabu, False), True),
        'RB-THC':      (lambda lv, rng: rb_thc(lv, rng, P, k, tabu, True), True),
        'GBFS':        (lambda lv, rng: gbfs(lv, rng, P), True),
    }
# CELL 6: parallel runner (fork-based; works on Colab/Linux)
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor

_JOBS = None
def _run_one(i):
    tier, li, solver, seed, P, k, tabu = _JOBS[i]
    lv = LEVELS[tier][li]
    fn, _ = make_solvers(P, k, tabu)[solver]
    r = fn(lv, random.Random(seed * 1_000_003 + li))
    trace = r.pop('trace')
    r.update(tier=tier, level=lv.name, solver=solver, seed=seed, k=k, tabu=tabu,
             n_boxes=len(lv.goals))
    return r, (trace if seed == 0 else None)

def run_grid(jobs, workers):
    global _JOBS; _JOBS = jobs
    rows, traces = [], {}
    t0 = time.time()
    with ProcessPoolExecutor(workers, mp_context=mp.get_context('fork')) as ex:
        for n, (r, tr) in enumerate(ex.map(_run_one, range(len(jobs)), chunksize=8)):
            rows.append(r)
            if tr is not None: traces[(r['tier'], r['level'], r['solver'], r['k'], r['tabu'])] = tr
            if (n + 1) % 500 == 0: print(f"  {n+1}/{len(jobs)} runs, {time.time()-t0:.0f}s")
    return pd.DataFrame(rows), traces
# CELL 17: fair-memory check — GBFS with the SAME memory cap as RB-THC (k + T states)
def gbfs_capped(lv, rng, P, cap):
    """GBFS whose open + closed lists together never exceed `cap` entries
       (conservative: open entries are also counted in closed until evicted).
       Closed = FIFO (oldest forgotten); open trimmed to its best entries."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    cap_c = cap // 2; cap_o = cap - cap_c
    s0 = canon(lv, lv.player0, lv.boxes0); h0 = heuristic(lv, s0[1], hk)
    openl = [(h0, rng.random(), (s0, None))]
    closed = collections.deque([s0]); cset = {s0}
    best_node, best_h, trace = (s0, None), h0, []
    while openl and not ctr.out():
        h, _, nd = heapq.heappop(openl)
        if is_goal(lv, nd[0]): return _result(lv, True, nd, 0.0, ctr, 'solved', trace)
        if h < best_h: best_h, best_node = h, nd
        for s in successors(lv, nd[0], ctr):
            if s in cset: continue
            closed.append(s); cset.add(s)
            if len(closed) > cap_c: cset.discard(closed.popleft())
            heapq.heappush(openl, (heuristic(lv, s[1], hk), rng.random(), (s, nd)))
        if len(openl) > cap_o:
            openl = heapq.nsmallest(cap_o, openl); heapq.heapify(openl)
        ctr.mem = max(ctr.mem, len(openl) + len(closed))
        trace.append((ctr.exp, best_h))
    return _result(lv, False, best_node, best_h, ctr, 'budget' if openl else 'exhausted', trace)

if '_BASE_MAKE' not in globals(): _BASE_MAKE = make_solvers   # safe to re-run this cell
def make_solvers(P, k=None, tabu=None):
    s = _BASE_MAKE(P, k, tabu)
    cap = (k or P['beam_width']) + (P['tabu_size'] if tabu is None else tabu)
    s['GBFS-cap'] = (lambda lv, rng: gbfs_capped(lv, rng, P, cap), True)
    return s

