import pickle, learned as L
from learned import *
from scipy.stats import wilcoxon
L.CLF = pickle.load(open('clf_gbt.pkl', 'rb')); P = dict(CFG)
rows = []
for t in ['medium', 'hard']:
    for li in range(15):
        lv = LEVELS[t][li]
        a = rb_thc(lv, random.Random(li), P, 4, 500, True); b = L.rb_thc_D(lv, random.Random(li), P, 4, 500, True)
        rows.append((a['time'] / a['expansions'], b['time'] / b['expansions']))
r = np.array(rows) * 1e6; print('median us/exp RB-THC %.0f  RB-THC-L %.0f  ratio %.2f' % (np.median(r[:, 0]), np.median(r[:, 1]), np.median(r[:, 1] / r[:, 0])))
R = '/tmp/claude-0/-home-claude/9d4af8a3-61da-54fe-9647-3e732ce2016f/scratchpad/repo/src/RESULTS/'
df = pd.concat([pd.read_csv(R + 'main_runs.csv'), pd.read_csv('full_new.csv')])
for t in ['medium', 'hard']:
    d = df[(df.tier == t) & (df.seed == 0) & df.solver.isin(['RB-THC', 'RB-THC-D']) & df.solved].pivot_table(index='level', columns='solver', values=['expansions', 'pushes']).dropna()
    for m in ['expansions', 'pushes']:
        x = d[(m, 'RB-THC-D')] - d[(m, 'RB-THC')]; print(t, m, len(d), 'p=%.4f' % wilcoxon(x, zero_method='zsplit').pvalue)
