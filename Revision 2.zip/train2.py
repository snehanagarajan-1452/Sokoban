import pickle, numpy as np, time
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score, precision_score, recall_score
X, y, g = pickle.load(open('train.pkl', 'rb')); d = (y == 60).astype(int)
models = {'logreg': lambda: make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, C=1.0)),
          'gbt': lambda: HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, max_leaf_nodes=31, random_state=0)}
for name, mk in models.items():
    p = np.zeros(len(d))
    for tr, te in GroupKFold(5).split(X, d, g): p[te] = mk().fit(X[tr], d[tr]).predict_proba(X[te])[:, 1]
    print(name, 'AUC %.3f' % roc_auc_score(d, p), end=' | ')
    for tau in [0.8, 0.9, 0.95]:
        print('tau %.2f prec %.3f rec %.3f' % (tau, precision_score(d, p > tau), recall_score(d, p > tau)), end=' | ')
    m = mk().fit(X, d); pickle.dump(m, open(f'clf_{name}.pkl', 'wb'))
    t = time.perf_counter(); [m.predict_proba(X[:12]) for _ in range(300)]; print('%.2f ms' % ((time.perf_counter() - t) / 300 * 1e3))
