import pandas as pd, numpy as np
from scipy.stats import wilcoxon, binomtest
R='/tmp/claude-0/-home-claude/9d4af8a3-61da-54fe-9647-3e732ce2016f/scratchpad/repo/src/RESULTS/'
df=pd.concat([pd.read_csv(R+'main_runs.csv'),pd.read_csv(R+'gbfs_capped_runs.csv'),pd.read_csv('full_new.csv').drop(columns=['pruned'],errors='ignore')])
def boot(x,B=2000,seed=0):
    rng=np.random.default_rng(seed);x=np.asarray(x);m=rng.choice(x,(B,len(x))).mean(1);return np.percentile(m,[2.5,97.5])
out={}
for (t,s),g in df.groupby(['tier','solver']):
    pl=g.groupby('level').solved.mean();lo,hi=boot(pl.values)
    out[(t,s)]=(100*g.solved.mean(),100*lo,100*hi,g.peak_stored_states.max(),g.time.mean(),(g.time/g.expansions.clip(lower=1)).median()*1e6)
T=pd.DataFrame(out,index=['rate','lo','hi','peakmax','tmean','us_exp']).T.round(2);print(T)
def paired(t,a,b):
    d=df[df.tier==t];rate=d.pivot_table(index='level',columns='solver',values='solved',aggfunc='mean')
    s0=d[d.seed==0].pivot_table(index='level',columns='solver',values='solved',aggfunc='first').astype(bool)
    x,y=s0[a],s0[b];n10,n01=int((x&~y).sum()),int((~x&y).sum())
    pm=binomtest(n10,n10+n01,.5).pvalue if n10+n01 else 1.0
    diff=rate[a]-rate[b];pw=wilcoxon(diff,zero_method='zsplit').pvalue if (diff!=0).any() else 1.0
    return n10,n01,pm,pw,100*diff.mean()
for t in ['unfiltered','medium','hard']:
    for b in ['RB-THC','GBFS-cap','A*']:
        print(t,'RB-THC-D vs',b,['%.4g'%v for v in paired(t,'RB-THC-D',b)])
    print(t,'RB-THC vs A*',['%.4g'%v for v in paired(t,'RB-THC','A*')])
# cost on commonly solved, RB-THC-D vs RB-THC (seed0)
for t in ['unfiltered','medium','hard']:
    d=df[(df.tier==t)&(df.seed==0)&df.solver.isin(['RB-THC','RB-THC-D'])&df.solved].pivot_table(index='level',columns='solver',values=['expansions','pushes']).dropna()
    print(t,'common',len(d),'median exp',d['expansions'].median().to_dict(),'median pushes',d['pushes'].median().to_dict())
n=pd.read_csv('full_new.csv');print(n[n.solver=='RB-THC-D'].groupby('tier').pruned.median())
f=n[(n.solver=='RB-THC-D')&~n.solved];print(f.groupby('tier').reason.value_counts())
print('time capped', (n.time>9.9).groupby(n.solver).sum())
