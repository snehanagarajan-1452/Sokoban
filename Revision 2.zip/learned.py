from rbthc_core import *
import rbthc_core as C

def feats(lv, state):
    player, boxes = state
    bset = set(boxes); W = lv.W
    cost = lv.gdist[:, list(boxes)].T
    cost = np.where(np.isinf(cost), 1e6, cost)
    r, c = linear_sum_assignment(cost); hm = float(cost[r, c].sum())
    near = float(sum(min(abs(b // W - g // W) + abs(b % W - g % W) for g in lv.goals) for b in boxes))
    goals = set(lv.goals)
    off = [b for b in boxes if b not in goals]
    blocked = lambda x: x in lv.walls or x not in lv.floor or x in bset
    wall = lambda x: x in lv.walls or x not in lv.floor
    n_wall = sum(1 for b in off if any(wall(b + d) for d in lv.dirs))
    frozen = 0; sq = 0
    for b in off:
        v = blocked(b - W) or blocked(b + W); h = blocked(b - 1) or blocked(b + 1)
        frozen += int(v and h)
        for a in (b, b - 1, b - W, b - W - 1):
            cells = (a, a + 1, a + W, a + W + 1)
            if all(blocked(x) or x == b for x in cells): sq += 1; break
    adj = sum(1 for b in boxes for d in (1, W) if b + d in bset)
    rch = reach(lv, player, bset)
    mob = 0
    for b in boxes:
        for d in lv.dirs:
            dest = b + d
            if (b - d) in rch and dest in lv.floor and dest not in bset and dest not in lv.dead: mob += 1
    mx = float(max(np.min(cost, axis=1)))
    return [hm, near, len(boxes) - len(off), len(off), mx, n_wall, frozen, sq, adj,
            len(rch) / len(lv.floor), mob]

FEATS = ['h_match', 'h_manhattan', 'on_goal', 'off_goal', 'max_box_dist', 'off_goal_at_wall',
         'frozen_like', 'blocked_2x2', 'adjacent_pairs', 'reach_frac', 'mobility']

MODEL = None
def hL(lv, states):
    X = np.array([feats(lv, s) for s in states])
    return MODEL.predict(X)

def rb_thc_L(lv, rng, P, k, tabu_size, restarts=True):
    """RB-THC with the learned heuristic h_L (batched prediction per iteration)."""
    ctr = Counter(P['max_expansions'], P['time_limit'])
    s0 = canon(lv, lv.player0, lv.boxes0)
    start = (s0, None)
    best_node, best_h, trace = start, float(hL(lv, [s0])[0]), []
    while True:
        beam = [(float(hL(lv, [start[0]])[0]), start)]
        tabu = collections.deque(); tabu_set = set(); stall = 0
        while not ctr.out():
            for h, nd in beam:
                if is_goal(lv, nd[0]): return C._result(lv, True, nd, 0.0, ctr, 'solved', trace)
            raw, seen = [], set()
            for h, nd in beam:
                if ctr.out(): break
                for s in successors(lv, nd[0], ctr):
                    if s in tabu_set or s in seen: continue
                    seen.add(s); raw.append((s, nd))
            if tabu_size:
                for h, nd in beam:
                    if nd[0] not in tabu_set:
                        tabu.append(nd[0]); tabu_set.add(nd[0])
                        if len(tabu) > tabu_size: tabu_set.discard(tabu.popleft())
            if not raw: break
            # goal states get h = 0 exactly
            hs = hL(lv, [s for s, _ in raw])
            cands = [(0.0 if is_goal(lv, s) else float(hv), (s, nd)) for hv, (s, nd) in zip(hs, raw)]
            beam = C._rank(cands, rng)[:k]
            ctr.mem = max(ctr.mem, len(tabu_set) + len(beam))
            if beam[0][0] < best_h: best_h, best_node, stall = beam[0][0], beam[0][1], 0
            else: stall += 1
            trace.append((ctr.exp, best_h))
            if restarts and stall >= P['patience']: break
        if ctr.out():
            return C._result(lv, False, best_node, best_h, ctr, 'budget', trace)
        if not restarts:
            return C._result(lv, False, best_node, best_h, ctr, 'no_candidates', trace)
        start = C._random_walk(lv, s0, rng, P['walk_len'], ctr)

def astar(lv, rng, P):
    """A* with the same (admissible) matching heuristic: optimal-solver family reference."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    s0 = canon(lv, lv.player0, lv.boxes0); h0 = heuristic(lv, s0[1], hk)
    openl = [(h0, 0, rng.random(), (s0, None))]; gbest = {s0: 0}
    best_node, best_h, trace = (s0, None), h0, []
    while openl and not ctr.out():
        f, g, _, nd = heapq.heappop(openl)
        if g > gbest.get(nd[0], 1e18): continue
        if is_goal(lv, nd[0]): return C._result(lv, True, nd, 0.0, ctr, 'solved', trace)
        if f - g < best_h: best_h, best_node = f - g, nd
        for s in successors(lv, nd[0], ctr):
            ng = g + 1
            if ng < gbest.get(s, 1e18):
                gbest[s] = ng; heapq.heappush(openl, (ng + heuristic(lv, s[1], hk), ng, rng.random(), (s, nd)))
        ctr.mem = len(gbest)
        trace.append((ctr.exp, best_h))
    return C._result(lv, False, best_node, best_h, ctr, 'budget' if openl else 'exhausted', trace)

CLF = None; TAU = 0.9
def rb_thc_D(lv, rng, P, k, tabu_size, restarts=True):
    """RB-THC + learned dead-end pruning: ranking by the matching heuristic as before;
       candidates whose predicted dead-end probability exceeds TAU are discarded."""
    ctr = Counter(P['max_expansions'], P['time_limit']); hk = P['heuristic']
    s0 = canon(lv, lv.player0, lv.boxes0); start = (s0, None)
    best_node, best_h, trace = start, heuristic(lv, s0[1], hk), []
    pruned = 0
    while True:
        beam = [(heuristic(lv, start[0][1], hk), start)]
        tabu = collections.deque(); tabu_set = set(); stall = 0
        while not ctr.out():
            for h, nd in beam:
                if is_goal(lv, nd[0]):
                    r = C._result(lv, True, nd, 0.0, ctr, 'solved', trace); r['pruned'] = pruned; return r
            cands, seen = [], set()
            for h, nd in beam:
                if ctr.out(): break
                for s in successors(lv, nd[0], ctr):
                    if s in tabu_set or s in seen: continue
                    seen.add(s); cands.append((heuristic(lv, s[1], hk), (s, nd)))
            if cands:
                idx = [i for i, c in enumerate(cands) if not is_goal(lv, c[1][0])]
                if idx:
                    pd_ = CLF.predict_proba(np.array([feats(lv, cands[i][1][0]) for i in idx]))[:, 1]
                    drop = {i for i, p in zip(idx, pd_) if p > TAU}; pruned += len(drop)
                    cands = [c for i, c in enumerate(cands) if i not in drop]
            if tabu_size:
                for h, nd in beam:
                    if nd[0] not in tabu_set:
                        tabu.append(nd[0]); tabu_set.add(nd[0])
                        if len(tabu) > tabu_size: tabu_set.discard(tabu.popleft())
            if not cands: break
            beam = C._rank(cands, rng)[:k]
            ctr.mem = max(ctr.mem, len(tabu_set) + len(beam))
            if beam[0][0] < best_h: best_h, best_node, stall = beam[0][0], beam[0][1], 0
            else: stall += 1
            trace.append((ctr.exp, best_h))
            if restarts and stall >= P['patience']: break
        if ctr.out():
            r = C._result(lv, False, best_node, best_h, ctr, 'budget', trace); r['pruned'] = pruned; return r
        if not restarts:
            r = C._result(lv, False, best_node, best_h, ctr, 'no_candidates', trace); r['pruned'] = pruned; return r
        start = C._random_walk(lv, s0, rng, P['walk_len'], ctr)
