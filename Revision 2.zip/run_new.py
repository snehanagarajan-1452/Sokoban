import sys, pickle
import learned as L
from learned import *
L.MODEL = pickle.load(open('model.pkl', 'rb')); L.CLF = pickle.load(open('clf_gbt.pkl', 'rb'))
P = dict(CFG)
SOLV = {'RB-THC-D': lambda lv, rng: L.rb_thc_D(lv, rng, P, 4, 500, True), 'RB-THC-L': lambda lv, rng: L.rb_thc_L(lv, rng, P, 4, 500, True),
        'A*': lambda lv, rng: L.astar(lv, rng, P)}
J = None
def one(i):
    t, li, s, sd = J[i]; lv = LEVELS[t][li]
    r = SOLV[s](lv, random.Random(sd * 1_000_003 + li)); r.pop('trace')
    r.update(tier=t, level=lv.name, solver=s, seed=sd, k=4, tabu=500, n_boxes=len(lv.goals)); return r
if __name__ == '__main__':
    solvers = sys.argv[1].split(','); nlev = int(sys.argv[2]); out = sys.argv[3]
    J = [(t, li, s, sd) for t in LEVELS for li in range(nlev) for s in solvers for sd in CFG['seeds']]
    import multiprocessing as mp; from concurrent.futures import ProcessPoolExecutor
    t0 = time.time(); rows = []
    with ProcessPoolExecutor(2, mp_context=mp.get_context('fork')) as ex:
        for n, r in enumerate(ex.map(one, range(len(J)), chunksize=4)):
            rows.append(r)
            if (n + 1) % 300 == 0: print(n + 1, len(J), f'{time.time()-t0:.0f}s', flush=True)
    df = pd.DataFrame(rows); assert df.loc[df.solved, 'verified'].all(); df.to_csv(out, index=False)
    print(df.groupby(['tier', 'solver']).agg(rate=('solved', 'mean'), t=('time', 'mean'), exp=('expansions', 'median')).round(3), f'{time.time()-t0:.0f}s')
